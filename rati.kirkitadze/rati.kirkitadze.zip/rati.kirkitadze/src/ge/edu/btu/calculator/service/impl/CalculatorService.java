package ge.edu.btu.calculator.service.impl;

public abstract interface CalculatorService {
    void sum(int x, int y);
    void divide(int x, int y);
}